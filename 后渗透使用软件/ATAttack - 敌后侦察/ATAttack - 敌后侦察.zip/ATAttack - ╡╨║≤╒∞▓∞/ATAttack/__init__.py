#! /usr/bin/env python2.7
# -*- coding: utf-8 -*-

import sys,os
BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
